Use tempdb
set nocount on
go

IF OBJECT_ID(N'Customers', N'U') IS NOT NULL
   DROP TABLE dbo.Customers;
   
CREATE TABLE dbo.Customers (
 customer_nbr INT NOT NULL PRIMARY KEY,
 customer_name VARCHAR(35) NOT NULL);
 
CREATE NONCLUSTERED INDEX ix_customers
ON dbo.Customers(customer_name);
 
INSERT dbo.Customers VALUES(1, 'Joe');
INSERT dbo.Customers VALUES(2, 'Leo');
INSERT dbo.Customers VALUES(3, 'Dave');
INSERT dbo.Customers VALUES(4, 'Lenny');
INSERT dbo.Customers VALUES(5, 'Larry');
INSERT dbo.Customers VALUES(6, 'Lefty');
INSERT dbo.Customers VALUES(7, 'Lemur');
GO

--SET SHOWPLAN_TEXT ON; see below
--show graphical plan
SELECT customer_name
FROM dbo.Customers
WHERE LEFT(customer_name, 1) = 'L'; --show query refactor by optimizer

/*

StmtText
--------------------------------------------------------------------------------------------------------------------------------------------------
  |--Index Scan(OBJECT:([Testing].[dbo].[Customers].[ix_customers]),  WHERE:(substring([Testing].[dbo].[Customers].[customer_name],(1),(1))='L'))

*/

--show seek predicate - rewritten by optimizer!
SELECT customer_name
FROM dbo.Customers
WHERE customer_name LIKE 'L%';

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Index Seek(OBJECT:([Testing].[dbo].[Customers].[ix_customers]), SEEK:([Testing].[dbo].[Customers].[customer_name] >= 'K�' AND [Testing].[dbo].[Customers].[customer_name] < 'M'),  WHERE:([Testing].[dbo].[Customers].[customer_name] like 'L%') ORDERED FO

*/

--SET SHOWPLAN_TEXT OFF;
--GO

DROP TABLE dbo.Customers;

IF OBJECT_ID(N'Sales', N'U') IS NOT NULL
   DROP TABLE dbo.Sales;

CREATE TABLE dbo.Sales (
 transaction_nbr INT NOT NULL PRIMARY KEY NONCLUSTERED,
 sale_date DATETIME NOT NULL,
 sale_amount DECIMAL(10, 2) NOT NULL);
 
CREATE CLUSTERED INDEX ix_sales
ON dbo.Sales(sale_date);
 
INSERT dbo.Sales VALUES(1, '20090101', 10.50);
INSERT dbo.Sales VALUES(2, '20080504', 11.25);
INSERT dbo.Sales VALUES(3, '20090304', 15.50);
INSERT dbo.Sales VALUES(4, '20090104', 11.50);
INSERT dbo.Sales VALUES(5, '20080504', 11.25);
INSERT dbo.Sales VALUES(6, '20090304', 15.50);
INSERT dbo.Sales VALUES(7, '20090201', 10.50);
INSERT dbo.Sales VALUES(8, '20080504', 11.25);
INSERT dbo.Sales VALUES(9, '20090304', 15.50);
INSERT dbo.Sales VALUES(10, '20080314', 25.50);

INSERT dbo.Sales VALUES(11, '20070101', 10.50);
INSERT dbo.Sales VALUES(12, '20070504', 11.25);
INSERT dbo.Sales VALUES(13, '20070304', 15.50);
INSERT dbo.Sales VALUES(14, '20070104', 11.50);
INSERT dbo.Sales VALUES(15, '20070504', 11.25);
INSERT dbo.Sales VALUES(16, '20070304', 15.50);
INSERT dbo.Sales VALUES(17, '20070201', 10.50);
INSERT dbo.Sales VALUES(18, '20070504', 11.25);
INSERT dbo.Sales VALUES(19, '20070304', 15.50);
INSERT dbo.Sales VALUES(20, '20070314', 25.50);

INSERT dbo.Sales VALUES(21, '20060101', 10.50);
INSERT dbo.Sales VALUES(22, '20060504', 11.25);
INSERT dbo.Sales VALUES(23, '20060304', 15.50);
INSERT dbo.Sales VALUES(24, '20060104', 11.50);
INSERT dbo.Sales VALUES(25, '20060504', 11.25);
INSERT dbo.Sales VALUES(26, '20060304', 15.50);
INSERT dbo.Sales VALUES(27, '20060201', 10.50);
INSERT dbo.Sales VALUES(28, '20060504', 11.25);
INSERT dbo.Sales VALUES(29, '20060304', 15.50);
INSERT dbo.Sales VALUES(30, '20060314', 25.50);
GO

--SET SHOWPLAN_TEXT ON; show actual execution plan
--GO

SELECT SUM(sale_amount) AS total_sales
FROM dbo.Sales
WHERE DATEPART(YEAR, sale_date) = 2009
  AND DATEPART(MONTH, sale_date) = 1;

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1007]=(0) THEN NULL ELSE [Expr1008] END))
       |--Stream Aggregate(DEFINE:([Expr1007]=Count(*), [Expr1008]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), WHERE:(datepart(year,[Testing].[dbo].[Sales].[sale_date])=(2009) AND datepart(month,[Testing].[dbo].[Sales].[sale_date])=(1)))

*/

SELECT SUM(sale_amount) AS total_sales
FROM dbo.Sales
WHERE sale_date >= '20090101'
  AND sale_date <  '20090201';

/*

StmtText
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1007]=(0) THEN NULL ELSE [Expr1008] END))
       |--Stream Aggregate(DEFINE:([Expr1007]=Count(*), [Expr1008]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Clustered Index Seek(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), SEEK:([Testing].[dbo].[Sales].[sale_date] >= CONVERT_IMPLICIT(datetime,[@1],0) AND [Testing].[dbo].[Sales].[sale_date] < CONVERT_IMPLICIT(datetime,[@2],0)) ORDERED FORWARD)

*/

/* SQL Server 2008+ */
SELECT SUM(sale_amount) AS total_sales
FROM dbo.Sales
WHERE CAST(sale_date AS DATE) = '20090101';

/*

StmtText
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Compute Scalar(DEFINE:([Expr1004]=CASE WHEN [Expr1010]=(0) THEN NULL ELSE [Expr1011] END))
       |--Stream Aggregate(DEFINE:([Expr1010]=Count(*), [Expr1011]=SUM([Testing].[dbo].[Sales].[sale_amount])))
            |--Nested Loops(Inner Join, OUTER REFERENCES:([Expr1008], [Expr1009], [Expr1007]))
                 |--Compute Scalar(DEFINE:(([Expr1008],[Expr1009],[Expr1007])=GetRangeThroughConvert(CONVERT_IMPLICIT(date,[@1],0),CONVERT_IMPLICIT(date,[@1],0),(62))))
                 |    |--Constant Scan
                 |--Clustered Index Seek(OBJECT:([Testing].[dbo].[Sales].[ix_sales]), SEEK:([Testing].[dbo].[Sales].[sale_date] > [Expr1008] AND [Testing].[dbo].[Sales].[sale_date] < [Expr1009]),  WHERE:(CONVERT(date,[Testing].[dbo].[Sales].[sale_date],0)=

*/

DROP TABLE dbo.Sales; 

/* KEY TAKEAWAY

   NEVER wrap a column in a function in a WHERE clause if possible - and it usually is

*/

