--lets report on countries with cool accents!

SELECT * FROM Sales.SalesTerritory

TerritoryID Name                                               CountryRegionCode Group                                              SalesYTD              SalesLastYear         CostYTD               CostLastYear          rowguid                              ModifiedDate
----------- -------------------------------------------------- ----------------- -------------------------------------------------- --------------------- --------------------- --------------------- --------------------- ------------------------------------ -----------------------
--sadly, no New Zealand! :-)
9           Australia                                          AU                Pacific                                            5977814.9154          2278548.9776          0.00                  0.00                  602E612E-DFE9-41D9-B894-27E489747885 2002-06-01 00:00:00.000
10          United Kingdom                                     GB                Europe                                             5012905.3656          1635823.3967          0.00                  0.00                  05FC7E1F-2DEA-414E-9ECD-09D150516FB5 2002-06-01 00:00:00.000


declare @TerritoryID int, @Territory9Amount money, @Territory10Amount money, @SubTotal money

set @Territory9Amount = 0
set @Territory10Amount = 0

--DECLARE workCursor CURSOR FOR
--DECLARE workCursor CURSOR --SCROLL DYNAMIC FOR
DECLARE workCursor CURSOR FAST_FORWARD FOR  --TRY TO ALWAYS USE FF!
SELECT TerritoryID, SubTotal
  FROM Sales.SalesOrderHeader
 WHERE OrderDate BETWEEN '6/1/2006' AND '8/31/2006'
   AND SalesPersonID = 282
   AND TerritoryID IN (9,10)

OPEN workCursor

FETCH NEXT FROM workCursor INTO @TerritoryID, @SubTotal

WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN

      if @TerritoryID = 9
      begin
         set @Territory9Amount = @Territory9Amount + @SubTotal
      end

      if @TerritoryID = 10
      begin
         set @Territory10Amount = @Territory10Amount + @SubTotal
      end

   END

   FETCH NEXT FROM workCursor INTO @TerritoryID, @SubTotal
END

CLOSE workCursor
DEALLOCATE workCursor

select 282 AS SalesPersonID, @Territory9Amount as Territory9Amount, @Territory10Amount as Territory10Amount

747 reads TO produce ONE ROW OF OUTPUT
699 FOR FF CURSOR

--take a step back and think of the requirement: add up Territory 9 and Territory 10 for Salesperson 282
--can we do that as set-based operation??
--YES!
SELECT 282 AS SalesPersonID,
       SUM(CASE WHEN TerritoryID =  9 THEN SubTotal ELSE 0 END) AS Territory9Amount,
       SUM(CASE WHEN TerritoryID = 10 THEN SubTotal ELSE 0 END) AS Territory10Amount
  FROM Sales.SalesOrderHeader
 WHERE OrderDate BETWEEN '6/1/2006' AND '8/31/2006'
   AND SalesPersonID = 282
   AND TerritoryID IN (9,10)


--But we have N SalesPersons to iterate through for the full report!


SET NOCOUNT ON
GO
DROP TABLE dbo.#output
go
CREATE TABLE dbo.#output (
   SalesPersonID int, 
   Territory9Amount money, 
   Territory10Amount money)
GO

declare @TerritoryID int, @Territory9Amount money, @Territory10Amount money, @SubTotal money, @SalesPersonID int


DECLARE SPCursor CURSOR FOR
--DECLARE SPCursor CURSOR --SCROLL DYNAMIC FOR
--DECLARE SPCursor CURSOR FAST_FORWARD FOR  --TRY TO ALWAYS USE FF!
SELECT BusinessEntityID AS SalesPersonID  --SERIOUSLY?!?
  FROM Sales.SalesPerson
--MISSING DATA DUE TO BAD DATA!!
UNION ALL SELECT NULL AS SalesPersonID

OPEN SPCursor

FETCH NEXT FROM SPCursor INTO @SalesPersonID

WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)
   BEGIN

      SET @Territory9Amount = 0
      set @Territory10Amount = 0

      DECLARE TECursor CURSOR FOR
      --DECLARE TECursor CURSOR --SCROLL DYNAMIC FOR
      --DECLARE TECursor CURSOR FAST_FORWARD FOR  --TRY TO ALWAYS USE FF!
      SELECT TerritoryID, SubTotal
        FROM Sales.SalesOrderHeader
       WHERE OrderDate BETWEEN '6/1/2006' AND '8/31/2006'
--         AND SalesPersonID = @SalesPersonID
         AND ISNULL(SalesPersonID, 0) = ISNULL(@SalesPersonID, 0)  --MUST HANDLE NULLS PROPERLY IF YOU LET THEM IN!!
         AND TerritoryID IN (9,10)

      OPEN TECursor

      FETCH NEXT FROM TECursor INTO @TerritoryID, @SubTotal

      WHILE (@@FETCH_STATUS <> -1)
      BEGIN
         IF (@@FETCH_STATUS <> -2)
         BEGIN

            if @TerritoryID = 9
            begin
               set @Territory9Amount = @Territory9Amount + @SubTotal
            end

            if @TerritoryID = 10
            begin
               set @Territory10Amount = @Territory10Amount + @SubTotal
            end

         END

         FETCH NEXT FROM TECursor INTO @TerritoryID, @SubTotal
      END

      CLOSE TECursor
      DEALLOCATE TECursor
      
      INSERT dbo.#output (SalesPersonID, Territory9Amount, Territory10Amount)
      VALUES (@SalesPersonID, @Territory9Amount, @Territory10Amount)
      
   END

   FETCH NEXT FROM SPCursor INTO @SalesPersonID
END

CLOSE SPCursor
DEALLOCATE SPCursor

select * FROM dbo.#output

Now 11919 READS FOR DEFAULT CURSOR!
11780 FOR FF CURSOR


--take ANOTHER step back and think of the requirement: add up Territory 9 and Territory 10 for EVERY Salesperson
--can we do that as set-based operation??
--YES!

SELECT SalesPersonID,
       SUM(CASE WHEN TerritoryID =  9 THEN SubTotal ELSE 0 END) AS Territory9Amount,
       SUM(CASE WHEN TerritoryID = 10 THEN SubTotal ELSE 0 END) AS Territory10Amount
  FROM Sales.SalesOrderHeader
 WHERE OrderDate BETWEEN '6/1/2006' AND '8/31/2006'
--   AND SalesPersonID = 282
   AND TerritoryID IN (9,10)
 GROUP BY SalesPersonID
 
SalesPersonID Territory9Amount      Territory10Amount
------------- --------------------- ---------------------
NULL          490389.5893           149532.6661
282           0.00                  189755.82
287           0.00                  73666.8667

--697 reads, and only because table scan!

--Also, go back and add in NULL salespersonid!
--12762 reads with NULL SalesPersonID included in the cursor solution

--What about if there is a covering index scenario?  Create this and rerun:


CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_KGBCovering] ON [Sales].[SalesOrderHeader] 
(
	OrderDate, TerritoryID
)
INCLUDE (SalesPersonID, SubTotal)
WITH (FILLFACTOR = 96, PAD_INDEX  = ON, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = ON, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


--cursor 3200+ reads
--set-based EIGHT READS!!!

--clean-up

DROP INDEX [IX_SalesOrderHeader_KGBCovering] ON [Sales].[SalesOrderHeader]
GO
 