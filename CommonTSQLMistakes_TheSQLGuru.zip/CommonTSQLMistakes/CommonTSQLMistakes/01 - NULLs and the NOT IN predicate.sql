use tempdb
set nocount on
go


IF OBJECT_ID(N'Colors', N'U') IS NOT NULL
   DROP TABLE dbo.Colors;
   
CREATE TABLE dbo.Colors (
 color VARCHAR(10) NOT NULL PRIMARY KEY);
 
INSERT INTO dbo.Colors VALUES('Blue');
INSERT INTO dbo.Colors VALUES('Red');
INSERT INTO dbo.Colors VALUES('Green');
INSERT INTO dbo.Colors VALUES('Black');

SELECT color FROM dbo.Colors;

/*

color
----------
Black
Blue
Green
Red

*/

IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE dbo.Products;

CREATE TABLE dbo.Products (
 sku INT NOT NULL PRIMARY KEY,
 product_description VARCHAR(30) NOT NULL,
 color VARCHAR(10));
 
INSERT INTO dbo.Products VALUES(1, 'Ball', 'Red');
INSERT INTO dbo.Products VALUES(2, 'Bike', 'Blue');
INSERT INTO dbo.Products VALUES(3, 'Tent', NULL);

SELECT sku, product_description, color
FROM dbo.Products;

/*

sku  product_description  color
---- -------------------- ------
1    Ball                 Red
2    Bike                 Blue
3    Tent                 NULL

*/


SELECT C.color
FROM dbo.Colors AS C
WHERE C.color NOT IN (SELECT P.color 
                      FROM dbo.Products AS P);

/*

color
----------

(0 row(s) affected)

*/

/* EXISTS */
SELECT C.color
FROM dbo.Colors AS C
WHERE NOT EXISTS(SELECT * 
                 FROM dbo.Products AS P
                 WHERE C.color = P.color);

/*

color
----------
Black
Green

*/


/* IS NOT NULL in the subquery */
SELECT C.color
FROM dbo.Colors AS C
WHERE C.color NOT IN (SELECT P.color 
                      FROM dbo.Products AS P 
                      WHERE P.color IS NOT NULL);

/* EXCEPT */
SELECT color
FROM dbo.Colors
EXCEPT
SELECT color
FROM dbo.Products;

/* LEFT OUTER JOIN */
SELECT C.color
FROM dbo.Colors AS C
LEFT OUTER JOIN dbo.Products AS P
  ON C.color = P.color
WHERE P.color IS NULL;
  
DROP TABLE dbo.Colors, dbo.Products; 

/* KEY TAKEAWAYS

   1) design NULLs out of your schemas if possible

   2) ALWAYS test ALL NULL/NOT NULL data combinations 
      actually be sure to test ALL possible boundary conditions
*/

 