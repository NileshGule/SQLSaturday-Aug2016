Use TempDB
go
create table dbo.records (ID int identity NOT NULL, MyField varchar(10))
create table dbo.audittable (ID int NOT NULL, MyFieldOrig varchar(10), MyFieldNew varchar(10), recdate datetime)
go

insert dbo.records values ('aaa')
insert dbo.records values ('bbb')
insert dbo.records values ('ccc')

select * from dbo.records

create trigger dbo.badrecordaudit on records for update as
DECLARE @id int, @mycharorig varchar(10), @mycharnew varchar(10)

SELECT @id = i.ID, @myCharorig = d.myfield, @mycharnew = i.myfield
  FROM INSERTED i inner join DELETED d on d.ID = i.ID

INSERT dbo.AuditTable
VALUES (@id, @myCharorig, @mycharnew, getdate())
GO


update dbo.records
set myfield = 'zzz'
where id <= 2

select * from dbo.records

select * from dbo.audittable

drop trigger dbo.badrecordaudit
go

create trigger dbo.goodrecordaudit on records for update as
--SET-based approach to ensure get ALL records affected!

INSERT dbo.AuditTable
SELECT i.ID, d.myfield, i.myfield, getdate()
  FROM INSERTED i inner join DELETED d on d.ID = i.ID

--error handling?? :-)
GO

update dbo.records
set myfield = '123'
where id >= 2

select * from dbo.records

select * from dbo.audittable

drop table dbo.records
drop table dbo.audittable

/* KEY TAKEAWAY

   ALWAYS ensure triggers can handle more than one row!!
   
*/

