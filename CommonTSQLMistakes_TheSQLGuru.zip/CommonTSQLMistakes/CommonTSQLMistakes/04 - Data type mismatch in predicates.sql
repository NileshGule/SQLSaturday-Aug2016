Use tempdb
set nocount on
go

IF OBJECT_ID(N'Customers', N'U') IS NOT NULL
   DROP TABLE dbo.Customers;
   
CREATE TABLE dbo.Customers (
 customer_nbr INT NOT NULL PRIMARY KEY,
 first_name VARCHAR(35) NOT NULL,
 last_name VARCHAR(35) NOT NULL);
 
INSERT dbo.Customers VALUES(1, 'Jeff', 'Hull');
INSERT dbo.Customers VALUES(2, 'George', 'Brown');
INSERT dbo.Customers VALUES(3, 'Peter', 'Green');
INSERT dbo.Customers VALUES(4, 'Dona', 'Johnson');
INSERT dbo.Customers VALUES(5, 'Kevin', 'Boles');

--show actual plan
insert dbo.customers
select number, 'asdf', 'zzzz' --just dummy values that are not like Brown
from KGBTools.dbo.BigNumbers  --PUT A NUMBERS TABLE IN YOUR BAG OF TSQL TRICKS!!
where number between 6 and 50000

/* the above construct is SOOOOO much better than 49995 of these, or a while loop or cursor, etc!!! 
   log buffer flushes are crushing with this type of DML
INSERT dbo.Customers VALUES (6, 'asdf', 'zzzz')
INSERT dbo.Customers VALUES (7, 'asdf', 'zzzz')
INSERT dbo.Customers VALUES (8, 'asdf', 'zzzz')
INSERT dbo.Customers VALUES (9, 'asdf', 'zzzz')
...
INSERT dbo.Customers VALUES (50000, 'asdf', 'zzzz')
*/


CREATE NONCLUSTERED INDEX ix_customer_last_name
ON dbo.Customers (last_name);
GO

--SET SHOWPLAN_TEXT ON; show actual execution instead, note estimated number of rows
SET STATISTICS IO ON  --show profiler here too

SELECT first_name, last_name
  FROM dbo.Customers
 WHERE last_name = N'Brown';

/*

StmtText
-----------------------------------
  |--Clustered Index Scan(OBJECT:([Testing].[dbo].[Customers].[PK__Customer__C5F5E0D6166152B0]), 
  WHERE:(CONVERT_IMPLICIT(nvarchar(35),[Testing].[dbo].[Customers].[last_name],0)=[@1]))

*/

SELECT first_name, last_name
  FROM dbo.Customers
 WHERE last_name = 'Brown';

read improvement:  170.0/4 = 42.5 times better
cost improvement:  0.186986/0.0065704 = 28.5 times better

/*
StmtText
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  |--Nested Loops(Inner Join, OUTER REFERENCES:([tempdb].[dbo].[Customers].[customer_nbr]))
       |--Index Seek(OBJECT:([tempdb].[dbo].[Customers].[ix_customer_last_name]), SEEK:([tempdb].[dbo].[Customers].[last_name]='Brown') ORDERED FORWARD)
       |--Clustered Index Seek(OBJECT:([tempdb].[dbo].[Customers].[PK__Customers__37A5467C]), SEEK:([tempdb].[dbo].[Customers].[customer_nbr]=[tempdb].[dbo].[Customers].[customer_nbr]) LOOKUP ORDERED FORWARD)

*/

/* incorrect parameter data type */
CREATE PROCEDURE dbo.GetCustomerByLastName
 @last_name NVARCHAR(35)
AS
 SELECT first_name, last_name
   FROM dbo.Customers
  WHERE last_name = @last_name;
 
GO

EXEC dbo.GetCustomerByLastName @last_name = 'Brown';

DROP PROCEDURE dbo.GetCustomerByLastName;
GO

/* correct parameter data type */
CREATE PROCEDURE dbo.GetCustomerByLastName
 @last_name VARCHAR(35)
AS
 SELECT first_name, last_name
   FROM dbo.Customers
  WHERE last_name = @last_name;

GO

EXEC dbo.GetCustomerByLastName @last_name = 'Brown';

DROP PROCEDURE dbo.GetCustomerByLastName;
DROP TABLE dbo.Customers; 

/* KEY TAKEAWAY

   ALWAYS use the EXACT datatype.  There is NEVER EVER an excuse to not do so!!

*/

