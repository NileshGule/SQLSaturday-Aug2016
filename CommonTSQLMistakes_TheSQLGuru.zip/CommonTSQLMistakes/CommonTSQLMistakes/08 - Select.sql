Use tempdb
set nocount on
go

/* this first part shows one example of how you can break existing code by 
   altering table columns if using SELECT *.

   second part shows performance benefits to be gained if have covering index
*/

IF OBJECT_ID(N'Products', N'U') IS NOT NULL
   DROP TABLE dbo.Products;

CREATE TABLE dbo.Products (
 sku INT NOT NULL PRIMARY KEY,
 material_type VARCHAR(10) NOT NULL,
 product_description VARCHAR(35) NOT NULL);


INSERT dbo.Products VALUES(1, 'metal', 'Bike');
INSERT dbo.Products VALUES(2, 'plastic', 'Ball');
INSERT dbo.Products VALUES(3, 'plastic', 'Phone');

IF OBJECT_ID(N'PlasticProducts', N'U') IS NOT NULL
   DROP TABLE dbo.PlasticProducts;

CREATE TABLE dbo.PlasticProducts (
 sku INT NOT NULL PRIMARY KEY,
 material_type VARCHAR(10) NOT NULL,
 product_description VARCHAR(35) NOT NULL);

INSERT dbo.PlasticProducts
SELECT *
FROM dbo.Products
WHERE material_type = 'plastic';

ALTER TABLE dbo.Products
ADD effective_start_date DATETIME,
    effective_end_date DATETIME;

DELETE FROM dbo.PlasticProducts;
/*
INSERT dbo.PlasticProducts
SELECT *
FROM dbo.Products
WHERE material_type = 'plastic';

Column name or number of supplied values does not match table definition.

*/

INSERT dbo.PlasticProducts (sku, product_description, material_type)
SELECT sku, product_description, material_type
FROM dbo.Products
WHERE material_type = 'plastic';

GO

CREATE VIEW dbo.MetalProducts
AS
SELECT *
FROM dbo.Products
WHERE material_type = 'metal';

GO

SELECT *
FROM dbo.MetalProducts;

GO

ALTER TABLE dbo.Products
DROP COLUMN product_description;

GO

SELECT *
FROM dbo.MetalProducts;

/*

View or function 'MetalProducts' has more column names specified than columns defined.

*/

DROP VIEW dbo.MetalProducts;
DROP TABLE dbo.Products, dbo.PlasticProducts;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PERFORMANCE REASON TO NOT USE SELECT *
THERE ARE SEVERAL:  locking/blocking, CPU, network, middle tier, scans/bookmark lookups

USE AdventureWorks2012
set statistics io on
go

--useful index for frequent searches
create nonclustered index idx_PTH_TranDate on [Production].[TransactionHistory] (TransactionDate)
with (pad_index=on, fillfactor = 93, sort_in_tempdb=on, allow_page_locks=on, allow_row_locks=on)

select *
from [Production].[TransactionHistory]
where TransactionDate between '2007-09-02' and '2007-09-03'
where TransactionDate between '2008-09-02' and '2008-09-03'

.714 cost, table scan
Table 'TransactionHistory'. Scan count 1, logical reads 797

.212 cost, NC index SEEKS, bookmark lookup
Table 'TransactionHistory'. Scan count 1, logical reads 218


select TransactionDate, TransactionID
from [Production].[TransactionHistory]
where TransactionDate between '2007-09-02' and '2007-09-03'
--where TransactionDate between '2008-09-02' and '2008-09-03'

.00363 cost, NC index SEEK - NO BOOKMARK LOOKUP!
Table 'TransactionHistory'. Scan count 1, logical reads 3

.00363 cost, NC index SEEK - NO BOOKMARK LOOKUP!
Table 'TransactionHistory'. Scan count 1, logical reads 4

/* KEY TAKEAWAY

   Just don't do this - no excuse
   
   Also, do yourself a favor and always declare views with schemabinding to keep you out of trouble

*/

